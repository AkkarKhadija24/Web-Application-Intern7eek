import React from 'react';
import './Footer.css';

function Footer() {
  return (
    <div class="footer">
        <p>INTERN7EEK &copy; 2024</p>
    </div>
  );
}

export default Footer;
